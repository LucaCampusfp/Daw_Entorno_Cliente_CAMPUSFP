function parametrosSaludar(message){
    return alert(message);
}

function noParametrosSaludar(){
    alert("PORQUE ME SALUDAS OTRA VEZ AHORA SIN PARAMETROS IGUALMENTE MUCHAS GRACIAS");
}

parametrosSaludar("QUE TAL BUENOS DIAS");
noParametrosSaludar();




